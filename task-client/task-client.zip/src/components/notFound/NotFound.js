import React from 'react';

const NotFound = () => {
    return (
       <div className="container mb-5 pt-5">
           <h1 className="text-center">Page Not Found 404</h1>
       </div>
    );
};

export default NotFound;